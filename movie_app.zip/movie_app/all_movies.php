

<!DOCTYPE HTML>
<?php  include('dbconnect.php');
   $sql = 'SELECT * FROM showcase ORDER BY id DESC';
   $cat=mysqli_query($conn,$sql);
   
   
    
   ?>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
      <meta http-equiv="content-type" content="text/html" />
      <link rel="stylesheet"  href="css/style1.css" />
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
      <title>Untitled 1</title>
   </head>
   <body class="dashboard_pg">
      <header class="header_sec">
         <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle js_left_nav_toggle">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="#">Movie Lib App</a>
               </div>
            </div>
         </nav>
      </header>
      <section class="main_sec">
         <div id="leftSideNavBar" class="left_side_nav open">
            <div class="links_wrap">
               <div class="panel-group" id="sideNavLinks">
                  <div class="panel">
                     <a class="link_sec" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="all_movies.php">
                     <img src="images/dashboard.svg" class="icon grid_icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     All Movies
                     </a>
                  </div>
                  <div class="panel">
                     <a class="link_sec" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="add.php">
                     <img src="images/reports.svg" class="icon grid_icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     Add Movies
                     </a>
                  </div>
                  <div class="panel">
                     <a class="link_sec collapsed" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="list.php">
                     <img src="images/pencil.svg" class="icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     List Movies
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="cont_sec">
            <div class="box_sec">
               <div class="search_box">
                  <input type="text" placeholder="Search by movie name" class="search_in" name="seach_text" id="seach_text">
                  <span class="glyphicon glyphicon-search"></span>
               </div>
               <div id="result">
                  <?php
                     $output = "";
                     $sql = "select * from showcase";
                     $result = mysqli_query($conn, $sql);
                     if(mysqli_num_rows($result) >0){
                     while($row = mysqli_fetch_array($result))
                     {
                     $output .= '
                     <div class="col-md-4 result_row">
                     <div><img src="images/'.$row['img_url'].'" width="72px" height="52px"/></div>        
                     <div>'.$row["title"].'</div>
                     <div>'.$row["year"].'</div>
                     </div>
                     ';
                     }
                     echo $output;
                     }
                     ?>
               </div>
            </div>
         </div>
      </section>
      <script>
         function doconfirm(){
            job=confirm("Delete News ?");
            if(job!=true){
                return false;
            }
         }
         
         $(document).ready(function(){
            $('#seach_text').keyup(function(){
                var txt = $(this).val();
                        $('#result').html('');
                        $.ajax({
                    url: "fetch.php",
                    method :"post",
                    data : {search:txt},
                    dataType: "text",
                    success: function(data)
                    {
                        //alert(data);
                        $('#result').html(data);
                    }
                    });
                    
            });
         });
      </script>
   </body>
</html>

