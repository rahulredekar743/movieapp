<?php

include('dbconnect.php');
$sub_id=$_GET['id'];
$sql="delete from showcase where id='$sub_id'";
$res=mysqli_query($conn,$sql);
header('location:list.php');
mysqli_close($conn);
?>