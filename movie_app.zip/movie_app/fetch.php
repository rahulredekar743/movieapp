

<?php
   include('dbconnect.php');
   $val=$_POST["search"];
   
   if(empty($val) || $val== '')
   {
       $query = "";
   }
   else
   {
       $query = "where  title like '%".$val."%'";
   }
   
   $output = "";
   $sql = "select * from showcase  $query";
   $result = mysqli_query($conn, $sql);
   if(mysqli_num_rows($result) >0){
       while($row = mysqli_fetch_array($result))
       {
           $output .= '
           <div class="col-md-4 result_row">
           <div><img src="images/'.$row['img_url'].'" width="72px" height="52px"/></div>        
            <div>'.$row["title"].'</div>
             <div>'.$row["year"].'</div>
           </div>
           ';
       }
       echo $output;
   }else{
       echo "data not found";
   }
   ?>

