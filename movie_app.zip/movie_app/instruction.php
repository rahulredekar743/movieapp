Below are db and table details:
movie_app.sql is in sql folder
1. Database name - movie_app
2. table name - showcase