

<!DOCTYPE HTML>
<?php  include('dbconnect.php');
   $sql = 'SELECT * FROM showcase ORDER BY id DESC';
   $cat=mysqli_query($conn,$sql);
   ?>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
      <meta http-equiv="content-type" content="text/html" />
      <link rel="stylesheet"  href="css/style1.css" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
      <title>Untitled 1</title>
   </head>
   <body class="dashboard_pg">
      <header class="header_sec">
         <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle js_left_nav_toggle">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="#">Movie Lib App</a>
               </div>
            </div>
         </nav>
      </header>
      <section class="main_sec">
         <div id="leftSideNavBar" class="left_side_nav open">
            <div class="links_wrap">
               <div class="panel-group" id="sideNavLinks">
                  <div class="panel">
                     <a class="link_sec" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="all_movies.php">
                     <img src="images/dashboard.svg" class="icon grid_icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     All Movies
                     </a>
                  </div>
                  <div class="panel">
                     <a class="link_sec" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="add.php">
                     <img src="images/reports.svg" class="icon grid_icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     Add Movies
                     </a>
                  </div>
                  <div class="panel">
                     <a class="link_sec collapsed" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="list.php">
                     <img src="images/pencil.svg" class="icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     List Movies
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="cont_sec">
            <div class="box_sec">
               <div class="title">
                  Movies List
               </div>
               <table class="table">
                  <thead>
                     <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Year</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php  
                        $sqll = "select * from showcase ORDER BY id";
                        $rows1=mysqli_query($conn,$sqll);
                        $i=1; while($row=mysqli_fetch_assoc($rows1)) 
                        {
                        $rows[]= $row;
                        
                         }
                        //echo json_encode($rows);
                                                        
                        $i=1; while($row=mysqli_fetch_assoc($cat)) {
                        
                        ?>
                     <tr>
                        <td><?php echo $i;   ?></td>
                        <td><img src="images/<?php echo $row['img_url']; ?>" alt="image" width="72px" height="52px"/></td>
                        <td><?php echo $row['title'];   ?></td>
                        <td><?php $originalDate = $row['year']; 
                           $newDate = date("d-m-Y", strtotime($originalDate)); 
                           echo $newDate;  ?></td>
                        <td>   
                           <a href="edit.php?id1=<?php echo $row['id'];  ?>" class="btn btn-app">
                           <i class="fa fa-edit"></i> Edit
                           </a>
                           <a href="delete.php?id=<?php echo $row['id'];   ?>" class="btn btn-app" onclick="return doconfirm();">
                           <i class="fa fa-trash"></i> Delete
                           </a>
                        </td>
                     </tr>
                     <?php  $i++; }  ?>	
                  </tbody>
               </table>
            </div>
         </div>
      </section>
      <script>
         function doconfirm(){
            job=confirm("Delete News ?");
            if(job!=true){
                return false;
            }
         }
      </script>
   </body>
</html>

