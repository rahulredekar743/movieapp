<header class="main-header" >
 
<!--rashmi@train-de.com-->
    <!-- Logo -->
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background-color:#D5275A;">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
	  <!---<i class="glyphicon glyphicon-chevron-left"></i>--->
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
         

          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="images/d1.png" class="user-image" alt="User Image">
              <span class="hidden-xs">
			  
			  <?php  
			  error_reporting(0);
			  include('dbconnect.php');
					session_start();
					echo "Admin";
				  ?>
			  
			  </span>
            </a>
            <ul class="dropdown-menu">	
           <!-- User image -->
              <li class="user-header">
                <img src="images/d1.png" class="img-circle" alt="User Image" width="10px" height="10px">
                <!--<img src="../images/jayraj.png" width="100px" height="100px" alt="image" style="border-radius: 50px; opacity: 0.5;"/>-->
                <p> <!--  Fresh Boxx  -->
				 <?php
					echo "Admin";
		  ?>
            
                  <small>Siddappa Dodamani</small>
				  
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-right">
				
                  <a href="ad_logout.php" class="btn btn-default btn-flat">Logout</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar" style="overflow-x:scroll;">
      <!-- Sidebar user panel -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <?php
			  $sql2="select count(*) as id from news";
			  $cat2=mysqli_query($conn,$sql2);
			  $row2=mysqli_fetch_assoc($cat2);
             
			  ?>
     
        <li class="treeview">
          <a href="gallery.php">
            <img src="../images/gallery.png" width="20px" height="20px" alt="image" style="border-radius: 10px;"/>
            <span> Seach</span><span class="label label-success pull-right"><?php echo  $row2['id'];?></span>
            </a>
        </li> 
        <li class="treeview">
          <a href="gallery.php">
            <img src="../images/gallery.png" width="20px" height="20px" alt="image" style="border-radius: 10px;"/>
            <span> List</span><span class="label label-success pull-right"><?php echo  $row2['id'];?></span>
            </a>
        </li> 
        <li class="treeview">
          <a href="gallery.php">
            <img src="../images/gallery.png" width="20px" height="20px" alt="image" style="border-radius: 10px;"/>
            <span> Add</span><span class="label label-success pull-right"><?php echo  $row2['id'];?></span>
            </a>
        </li> 
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>