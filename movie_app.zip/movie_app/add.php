

<!DOCTYPE HTML>
<?php  include('dbconnect.php');
   if(isset($_POST['add'])) {
   	
   	function generateRandomString($length = 25) {
   	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
   	    $randomString = '';
   	    for ($i = 0; $i < $length; $i++) {
   	        $randomString .= $characters[rand(0, strlen($characters) - 1)];
   	    }
   	    return $randomString;
   	}
   
   
       $catimg1 = generateRandomString();
   	$allowedExts = array("gif", "jpeg", "jpg", "png");
   
   	$temp = explode(".", $_FILES["sub_catimg1"]["name"]);
   	$extension = end($temp);
   
   	$catimg1 = $catimg1 . "." . $extension;
   	move_uploaded_file($_FILES["sub_catimg1"]["tmp_name"],
   	"images/" . $catimg1);
       
   
   	
   $n_title=$_POST['n_title'];
   $n_date=$_POST['n_date'];
   
   
   $sql = "INSERT INTO showcase (img_url,title,year)
   VALUES ('$catimg1','$n_title','$n_date')";
   
   echo($sql);
   
   if (mysqli_query($conn, $sql)) {
     echo "<script> alert('Movie Detail Added Successfully'); </script>";
    header("Location:list.php");
   	}
   
   }
   ?>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
      <meta http-equiv="content-type" content="text/html" />
      <link rel="stylesheet"  href="css/style1.css" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
      <title>Untitled 1</title>
   </head>
   <body class="dashboard_pg">
      <header class="header_sec">
         <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle js_left_nav_toggle">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="#">Movie Lib App</a>
               </div>
            </div>
         </nav>
      </header>
      <section class="main_sec">
         <div id="leftSideNavBar" class="left_side_nav open">
            <div class="links_wrap">
               <div class="panel-group" id="sideNavLinks">
                  <div class="panel">
                     <a class="link_sec" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="all_movies.php">
                     <img src="images/dashboard.svg" class="icon grid_icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     All Movies
                     </a>
                  </div>
                  <div class="panel">
                     <a class="link_sec" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="add.php">
                     <img src="images/reports.svg" class="icon grid_icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     Add Movies
                     </a>
                  </div>
                  <div class="panel">
                     <a class="link_sec collapsed" data-toggle="collapse" data-parent="#sideNavLinks"
                        href="list.php">
                     <img src="images/pencil.svg" class="icon">
                     <img src="images/chevron-right.svg" class="icon_right">
                     List Movies
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="cont_sec">
            <div class="box_sec">
               <div class="title">
                  Add Movies
               </div>
               <div class="row form_box">
                  <div class="col-sm-12">
                     <div class="box box-success">
                        <div class="box-header with-border">
                        </div>
                        <form action="" method="POST" enctype="multipart/form-data">
                           <div class="box-body">
                              <div class="form-group col-sm-8">
                                 <label for="cat_img">Image :</label>
                                 <input type="file" name="sub_catimg1" id="" required="">
                              </div>
                              <div class="form-group col-sm-8">
                                 <label for="cat_title col-xs-8">Title :</label>
                                 <input type="text" class="form-control" name="n_title"  id="n_title" placeholder="Enter Title" required="">
                              </div>
                              <div class="form-group col-sm-8">
                                 <label for="Year">Year :</label>
                                 <input type="date" class="form-control" name="n_date"  id="n_date" placeholder="Enter Date in YYYY-MM-DD" required="">
                              </div>
                              <div class="pull-center col-xs-8">
                                 <button type="submit"  name="add" class="btn btn-block btn-success">Add</button>
                              </div>
                           </div>
                        </form>
                        <!-- Main row -->
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </body>
</html>

